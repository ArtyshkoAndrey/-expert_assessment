<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('nameHeader', 'Главная'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box">
          <span class="info-box-icon bg-info"><i class="fas fa-plus"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">Кол-во оцениванивавших</span>
            <span class="info-box-number"><?php echo e(App\Question::first()->ratings()->count()); ?></span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
      </div>

      <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box">
          <span class="info-box-icon bg-success"><i class="fas fa-question"></i></span>

          <div class="info-box-content">
            <span class="info-box-text">Кол-во вопросов</span>
            <span class="info-box-number"><?php echo e(App\Question::count()); ?></span>
          </div>
          <!-- /.info-box-content -->
        </div>
        <!-- /.info-box -->
      </div>
    </div>
  </div>

  <div class="container-fluid">
    <div class="row justify-content-center align-items-center">
      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <table class="table table-bordered pb-5">
              <thead>
              <tr class="font-weight-bolder text-center">
                <th colspan="2" scope="col">Блоки потенциала «цифрового города»</th>
                <th colspan="1" scope="col">Оценка</th>
              </tr>
              </thead>
              <tbody>
              <?php
                $count = 1;
                $countRatings = App\Rating::count() > 0;
              ?>
              <?php if($countRatings): ?>
                <?php $__currentLoopData = App\Group::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="font-weight-bolder group-header">
                    <?php if($i === 0): ?>
                      <th scope="row" class="text-center" width="50px">№</th>
                    <?php else: ?>
                      <th scope="row" class="text-center" width="50px"></th>
                    <?php endif; ?>
                    <td colspan="2"><?php echo e($group->name); ?></td>
                  </tr>
                  <?php $__currentLoopData = $group->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j=>$q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row" class="text-center"><?php echo e($count); ?></th>
                      <td><?php echo e($q->name); ?></td>
                      <td><?php echo e($q->ratings()->count() > 0 ? round(($q->ratings()->get()->sum('mark') / $q->ratings()->count())/100, 2) : 0); ?></td>
                    </tr>
                    <?php
                      $count++;
                    ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <tr class="font-weight-bolder text-center">
                  <td colspan="3">Нет данных</td>
                </tr>
              <?php endif; ?>
              </tbody>
            </table>
            <form action="<?php echo e(route('clearMarks')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-danger text-white text-center rounded-0 mt-3 mr-auto ml-auto d-block">Сброс данных</button>
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <table class="table table-bordered pb-5">
              <thead>
              <tr class="font-weight-bolder text-center">
                <th scope="col">Направления «цифрового города»</th>
                <th scope="col">Комплексная оценка</th>
              </tr>
              </thead>
              <tbody>
              <?php if($countRatings): ?>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr class="text-center">
                    <td><?php echo e($group->name); ?></td>
                    <td><?php echo e(round($Ak[$group->id], 2)); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr class="font-weight-bolder text-center">
                    <td>Интегральная оценка</td>
                    <td><?php echo e(round($C0, 2)); ?></td>
                  </tr>
              <?php else: ?>
                <tr class="font-weight-bolder text-center">
                  <td colspan="2">Нет данных</td>
                </tr>
              <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Уведомление</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo e(session('status')); ?>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script !src="">
    <?php if(session('message')): ?>
    $('#myModal').modal('show')
    <?php endif; ?>
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\expert\resources\views/admin/home.blade.php ENDPATH**/ ?>